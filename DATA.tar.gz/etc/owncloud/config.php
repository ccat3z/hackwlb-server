<?php
$CONFIG = array (
  'datadirectory' => '/var/lib/owncloud/data',
  'apps_path' => 
  array (
    0 => 
    array (
      'path' => '/usr/share/webapps/owncloud/apps',
      'url' => '/apps',
      'writable' => false,
    ),
  ),
  'version' => '9.0.5.2',
  'dbname' => 'owncloud',
  'dbhost' => 'localhost',
  'dbuser' => 'owncloud',
  'installed' => true,
  'loglevel' => '0',
  'instanceid' => 'ocpfa81osmoh',
  'passwordsalt' => 'MSpgbv42wakLMfPUMGPU90uB/Sv/0k',
  'secret' => 'VyKd7xcNygNx9SnbPhJpvgXMm+ZlQs9/6V4v3n4Tvieg55+n',
  'dbtype' => 'mysql',
  'dbtableprefix' => 'oc_',
  'dbpassword' => 'MjQ4MjQK',
  'logtimezone' => 'UTC',
  'integrity.check.disabled' => true,
);
